class MyException extends Exception{
	private String detail;

	MyException(String a){
		detail=a;
	}
}
class ExceptionDemo{
	static void create(String a) throws MyException{
		System.out.println("Called create("+ a +")");
	}
	public static void main(String args[]){
		try{
			create("first exception");
			create("second exception");
		}catch(MyException e){
			System.out.println("Caught"+e);
		}
	}
}