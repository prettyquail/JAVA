
import java.util.Random;
import java.util.Scanner;
public class Q_14 {

		// TODO Auto-generated method stub
		
		 public static void main(String args[]) {
			 Scanner sc=new Scanner(System.in);
			 Random num = new Random();
		      int res[][][]=new int[3][4][6];
		      
		      for ( int i = 0; i <3; i++ ) {
		    	  for(int j=0;j<4;j++) {
		    		  for(int k=0;k<6;k++) {
		         res[i][j][k] =num.nextInt(70);
		         System.out.print(res[i][j][k]);
			
		    		  }
		    	  }
		      }
		 }
	}


