import java.util.Scanner;
class fifth{
	public static void main(String[] args){
		int dividend,divisor,quotient;
		double rem;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of divident");
		dividend=sc.nextInt();
		System.out.println("Enter the value of divisor");
		divisor=sc.nextInt();
		quotient=dividend/divisor;
		System.out.println("Quotient="+quotient);
		rem=dividend%divisor;
		System.out.println("Remainder="+rem);
      }
}
		
		