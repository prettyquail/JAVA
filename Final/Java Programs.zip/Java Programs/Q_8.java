public class Q_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int product=1;
		for(int i=1;i<=15;i=i+2) {
			product=product*i;
			
		}
		System.out.println("Product="+product);

	}

}