


class Q_1 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
	System.out.println("It's been nice knowing you");
	System.out.println("Goodbye World");
    }
}
	