public class Q_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Number\t\tSqaure\t\tCube" );
		for(int i=1;i<=10;i++) {
			System.out.println(i+"\t\t "+i*i+"\t\t "+i*i*i+"\t\t ");
		}

	}

}