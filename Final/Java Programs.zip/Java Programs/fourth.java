class fourth{
	public static void main(String[] arg){
		char ch='a';
		int ascii=ch;
		System.out.println("ASCII Value of a is="+ascii);
	}
}