// Program 46
import java.util.*;
import java.lang.String;

interface payable{
  double getAmount();
}
class Invoice implements payable{
  String partnum;
  String partDesc;
  int quant;
  double item_price;
  Invoice(String partnum , String partDesc , int quant , double item_price){
    this.partnum = partnum;
    this.partDesc = partDesc;
    this.quant = quant;
    this.item_price = item_price;
  }
  public double getAmount(){
    return quant*item_price;
  }
}
class Employee implements payable{
  double sal;
  String fname;
  String lname;
  String socialSecuritynum;
  Employee(String fname , String lname , String ssn , double sal ){
    this.fname = fname;
    this.lname = lname;
    this.socialSecuritynum = ssn;
    this.sal = sal;
  }
  public double getAmount(){
    return sal;
  }
  void show(){
    System.out.println("Name: " + fname + " " + lname );
  }
}
class PayableInterface{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    /* ---------------------------------------For invoice-----------------------------------------------------------*/
    int quant;
    double item_price , amount;
    System.out.println("Enter the part number: ");
    String partnum = sc.nextLine();
    System.out.println("Enter the part Description: ");
    String partDesc = sc.nextLine();
    System.out.println("Enter Quantity: ");
    quant = sc.nextInt();
    System.out.println("Enter Item Price: ");
    item_price = sc.nextDouble();
    Invoice in = new Invoice(partnum , partDesc , quant , item_price);
    amount = in.getAmount();
    System.out.println("Amout to be payed to Invoice is: " + amount );
    /*---------------------------------------For Employee----------------------------------------------------------*/
    double sal=0.0;
    System.out.println("Enter first name and last name: ");
    String fname = sc.nextLine();
    String lname = sc.nextLine();
    System.out.println("Enter salary(weekly): ");
    sal = sc.nextDouble();
    System.out.println("Enter Social Security number: ");
    String ssn = sc.nextLine();
    Employee emp = new Employee(fname,lname,ssn,sal);
    sal = emp.getAmount();
    emp.show();
    System.out.println("Pay Amount : " + sal);
  }
}