//import java.util.Import;
class Box1{
 double width,height,depth;
 Box1(){ width=-1;  height=-1;  depth=-1;} 
 Box1(double len){ width=height=depth=len;} 
 Box1(double w,double h, double d){ width=w;  height=h;  depth=d;} 
 double volume(){ return width*height*depth; }
}
class BoxWt extends Box1{
double weight;
BoxWt(double w,double h, double d, double m)
      { super(w,h,d);  
        weight=m; 
      } 
}
class ReferenceDemo{
public static void main(String ar[])
 {BoxWt bw = new BoxWt(1,2,3,4);
  Box1 b2 = new Box1();
  double v =bw.volume();
  System.out.println("Volume of BoxWt = "+v);
  System.out.println("Weight of BoxWt = "+bw.weight); 
  b2=bw;   //assign BoxWt reference to BOx1 reference
  v = b2.volume(); 
  System.out.println(" Volume of Box1 = "+v);
  System.out.println("Weight of BoxWt = "+b2.weight); 
 }
}