import java.util.*;  
class ArrayCollection{  
	public static void main(String args[]){  
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		list.add("Riya");//Adding object in arraylist  
		list.add("Vamika");  
		list.add("Rita");  
		list.add("Manisha");  
		//Traversing list through Iterator  
		Iterator itr=list.iterator();  
		while(itr.hasNext()){  
			System.out.println(itr.next());  
		}  
	}  
}  