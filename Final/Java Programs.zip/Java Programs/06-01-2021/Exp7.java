import java.util.Scanner;
class Exp7{

     public static void main(String []args){
         
        try{
            Scanner sc=new Scanner(System.in);
            int a,b;
            System.out.println("Enter a");
            a=sc.nextInt();
            System.out.println("Enter b");
            b=sc.nextInt();
            if(b==0){
                int c=a/b;
                System.out.println("Result = " + c);
            }
           
        }
        catch(Exception e){
            System.out.println("Superclass Exception");
        }
        catch(ArithmeticException e)
        {
            System.out.println("Error");
        }
     }
}