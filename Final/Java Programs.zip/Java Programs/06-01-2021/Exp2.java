import java.util.Scanner;
public class Exp2{
	public static void main(String args[]){
		try{
			Scanner sc=new Scanner(System.in);
			int a[]=new int[5];
			System.out.println("Enter value");
			a[5]=sc.nextInt();
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Array index out of bound");
		}
	}
}