import java.io.File; 
import java.io.FileNotFoundException; 
import java.io.FileReader; 
 class Exp6 { 
  
    public static void main(String args[])  { 
        try { 
  
            // Following file does not exist 
            File file = new File("m.txt"); 
  
            FileReader fr = new FileReader(file); 
        } catch (FileNotFoundException e) { 
           System.out.println("File does not exist"); 
        } 
    } 
}