import java.util.Scanner;
class Exp4{
	public static void main(String args[]){
		try{
			Scanner sc=new Scanner(System.in);
			int a=Integer.parseInt("Manisha");
			
			System.out.println(a);
		}
		catch(NumberFormatException e){
		System.out.println("Number format exception"); 
		}
	}
}