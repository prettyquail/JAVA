import java.util.Scanner;
class Student{
	String fname="Manisha",lname;
	int roll;
}
class Exp3{
	public static void main(String args[]){
		try{
			Student obj;
			obj=null;
			System.out.println(obj.fname);
		}
		catch(NullPointerException e) { 
            System.out.println("NullPointerException.."); 
        }
	}
}