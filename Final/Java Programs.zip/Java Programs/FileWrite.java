import java.io.FileReader;
import java.io.FileWriter;

public class FileWrite{
	public static void main(String args[]){
	try{
		String name="C:\\Users\\Manisha\\Desktop\\Java Programs\\Hello.txt";
		FileWriter fw=new FileWriter(name);
		for(char c='A';c<='Z';c++){
			fw.write(c);
		}
		fw.close();

	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	}
}