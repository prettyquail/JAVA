class sixth{
 
	public static void calc(int n){
   
 	if(n<=100){
  		System.out.print(n+" ");
		calc(n+1);
 	   }

	}
	public static void main(String[] args){
		int num=1;
		calc(num);

	}
}