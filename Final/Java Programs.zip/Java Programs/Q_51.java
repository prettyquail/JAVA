import java.util.Arrays;
class Q_51{
	public static void main(String args[]){
		String[] s = { "sort", "string", "array" };
		Arrays.sort(s);
		System.out.println(Arrays.toString(s));

	}
}