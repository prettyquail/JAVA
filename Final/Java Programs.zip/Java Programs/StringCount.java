import java.lang.String;
import java.util.Scanner;

class StringCount{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    int char_count=0, word_count=1;
    System.out.println("Enter a String: ");
    String st = sc.nextLine();
    int len = st.length();
    System.out.println(len);
    for(int i=0 ; i<len ; i++){
      if(st.charAt(i) != ' '){ char_count++;  }
      else { word_count++;}
    }
    System.out.println("Characters in the string are: " + char_count + "\nWords in the string are: " + word_count);
  }
}