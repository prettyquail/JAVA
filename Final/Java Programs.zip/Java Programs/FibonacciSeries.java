import java.util.Scanner;
class FibonacciSeries{
  static int fibo(int num){
    if(num == 0){  return 0;   }
    else if(num == 1)  {return 1;  }
    else {return fibo(num-1)+fibo(num-2);}
  }
  public static void main(String args[])
  {
    int num,i=0;
    System.out.println("Enter the number of terms in the series : ");
    Scanner sc = new Scanner(System.in);
    num = sc.nextInt();
    System.out.println("Fibonacci Series: ");
    while(i<num)
    {
      System.out.println(fibo(i));
      i++;
    }
  }
}