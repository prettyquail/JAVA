import java.awt.*;
import java.applet.*;
/*
<applet code="Circle_Rect_Fill.class" width=300 height=200>
</applet>
*/
public class Circle_Rect_Fill extends Applet{
  public void paint(Graphics g)
  {
    g.setColor(Color.yellow);
    g.fillRect(10,10,60,50);
    g.setColor(Color.magenta);
    g.fillOval(20,20,30,30);
  }
}