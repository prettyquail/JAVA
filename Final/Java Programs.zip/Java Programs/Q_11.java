
public class Q_11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	    double p=1000.0,r;
	    int t=3;
	    double temp;
	    double m;
	    for(r=5;r<=10;r++) {
	    	m=(1+(r/100));
	    	temp=1;
	    for(int i=1;i<=t;i++) {
	    	temp=temp*m;
	    
	    }
	    
	    
	    double amount=p*temp;
	    System.out.println("Amount="+amount);
	    double ci=amount-p;
	    System.out.println("Compound Interest="+ci);
	    }
  }
}
