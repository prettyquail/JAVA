import java.awt.*;
import java.applet.*;

/*
<applet code="House.class" width=400 height=450></applet>
*/
public class House extends Applet
{
public void paint(Graphics g)
  { int [] x = {150, 300, 225};
    int [] y = {150, 150, 25};
    g.setColor(Color.yellow);
    g.fillRect(150, 150, 150, 200); //House
    g.setColor(Color.black);
    g.fillRect(200, 200, 50, 150); // Door
    g.setColor(Color.magenta);
    g.fillOval(200, 75, 50, 50); // Skylight
    g.setColor(Color.green);
    g.fillPolygon(x, y, 3); // Roof
}
}