import java.util.Scanner;
class Sumupperlower{
  public static void main(String args[])
  {
    int r,c;
    r = c =3;
    Scanner sc = new Scanner(System.in);
    int matrix[][] = new int[r][c];
    System.out.println("Enter the elements in the array: ");
    for(int i=0 ; i<r ; i++)
    {
      for(int j=0; j<c ; j++)
        { matrix[i][j]=sc.nextInt(); }
    }
    lowertrianglesum(matrix,r,c);
    uppertrianglesum(matrix,r,c);
  }
  static void lowertrianglesum(int matrix[][],int r, int c)
  {int sum=0;
    for(int i=0 ; i<r ; i++)
    {
      for(int j=0; j<c ; j++)
        { if(j<i)
           sum += matrix[i][j]; }
    }
    System.out.println("Sum of Lower triangular matrix is : " + sum);
  }
  static void uppertrianglesum(int matrix[][],int r, int c)
  { int sum=0;
    for(int i=0 ; i<r ; i++)
    {
      for(int j=0; j<c ; j++)
         { if(i<j)
           sum += matrix[i][j]; }
     }
     System.out.println("Sum of Upper triangular matrix is : " + sum);
  }
}