class Employee{
	String firstname,lastname;
	double salary,hra,da,gross_sal;
	
    Employee(String fname,String lname,double sal){
    	firstname=fname;
    	lastname=lname;
    	salary=sal;
    }
    void display(){
    	System.out.println("First Name:"+firstname);
    	System.out.println("Last name:"+lastname);
    	System.out.println("Salary:"+salary);
    }
    void gsalary(){
    	if(salary<15000)
		{
			hra=0.1*salary;
			da=0.9*salary;
		}
		else
		{
			hra=500;
			da=0.98*salary;
		}
		gross_sal=salary+hra+da;
		System.out.println("Gross Salary:"+gross_sal);
    }
}
class Main{
	public static void main(String args[]){
		Employee obj1=new Employee("Manisha","Sahu",5000.0);
		obj1.display();
		obj1.gsalary();
	}
}