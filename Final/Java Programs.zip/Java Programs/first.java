import java.util.Scanner;

class first{
  
public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
	int num;
	System.out.println("Enter an integer");
	num=sc.nextInt();
	System.out.println("Number="+num);
     }
}