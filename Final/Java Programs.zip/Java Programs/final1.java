class final1 {
	class A{
		final void meth(){
			System.out.println("This is a final method.");
		}
	}

	class B extends A{
		void meth(){
			System.out.println("Illegal");
		}
	}
	public static void main(String args[]){
		B obj1=new B();
		obj1.meth();
	}
}