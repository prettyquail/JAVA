package myPackage;

public class MyClassOne
{
    public void getNames(String s)
    {        
        System.out.println(s);        
    }
}