package myPackage;

public class MyClassTwo
{
    public void getNames(String s)
    {        
        System.out.println(s);        
    }
}