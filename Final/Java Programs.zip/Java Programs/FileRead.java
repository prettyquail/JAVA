import java.io.FileReader;
import java.io.FileWriter;

public class FileRead{
    public static void main(String args[]){
    try{
String name="C:\\Users\\Manisha\\Desktop\\Java Programs\\Hello.txt";
        FileReader fr=new FileReader(name);
        int x;
        while((x=fr.read())!=-1){
            System.out.print((char)x);
        }
        fr.close();

    }catch(Exception e){
        System.out.println(e.getMessage());
    }
    }
}