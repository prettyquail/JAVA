import java.awt.*;
import java.applet.*;

/*
<applet code="Picture.class" width=300 height=200>
</applet>
*/
public class Picture extends Applet
{
  Image p;
  public void init()
  {
    p = getImage(getDocumentBase(),"5.jpg");
  }
  public void paint(Graphics g)
  {
    for(int i=0;i<500;i++)
    {
      g.drawImage(p, i,50, this);
      try
      {
        Thread.sleep(200);
      }
      catch(Exception e)
      {}
    }
  }
}