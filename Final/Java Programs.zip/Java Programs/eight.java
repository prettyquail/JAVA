
import java.util.Scanner;
import java.lang.Math;
class eight{

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int number;
		int a;
		number=sc.nextInt();
		int orignalNum=number;
		String length = Integer.toString(number);
	
		int i;
		double sum=0.0;
		
		while(number>0) {
			a=number%10;
		
			number=number/10;
			
			sum=sum+Math.pow(Double.valueOf(a),Double.valueOf(length.length()));
			
			
		}
		if(orignalNum==sum) {
			System.out.println("It is an Armstrong number");
		}
		else {
			System.out.println("It is not an Armstrong number");
		}
	    
	}

}