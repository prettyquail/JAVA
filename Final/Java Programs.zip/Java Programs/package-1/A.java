package P;

 public class A{
	public void msg(){
		System.out.println("From class A");
	}
}