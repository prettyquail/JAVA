import java.util.Scanner;
class ninth{
	public static void main(String[] args)
	{
		int number;
		System.out.println("Enter the number");
		Scanner sc=new Scanner(System.in);
		number=sc.nextInt();
		System.out.println("Factors are=");
		for(int i=1;i<number;i++){
			if(number%i==0){

			  System.out.println(i);
		        }
		}
	}
}