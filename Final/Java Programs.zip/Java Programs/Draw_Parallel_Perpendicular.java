 import java.awt.*;
import java.applet.*;
/*
<applet code="Draw_Parallel_Perpendicular.class" width=300 height=200>
</applet>
*/
public class Draw_Parallel_Perpendicular extends Applet{
  public void paint(Graphics g)
  {
    g.drawLine(100,100,200,200);
    g.drawLine(200,200,400,400);
  /*  g.drawLine(0,0,100n,50);
    g.drawLine(0,0,100n,50);*/
  }
}