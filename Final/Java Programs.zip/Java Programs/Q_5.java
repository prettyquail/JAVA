
public class Q_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=5,b=5,c=5,d=5,e=5;
		int average;
		average=(a+b+c+d+e)/5;
		System.out.println(average);
		

	}

}