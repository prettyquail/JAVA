import java.util.Scanner;
public class Q_12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		Scanner sc=new Scanner(System.in);
		int[][] array=new int[n][2];
		double[] total;
		double[] price= {99.90 ,20.20 ,6.87 ,45.50,40.49};
		System.out.println("Enter the Product id and Quantity sold");
		for(int i=0;i<n;i++) {
			
		   array[i][0]=sc.nextInt();
		   array[i][1]=sc.nextInt();
			
		}
		
		
			   
	   for(int i=0;i<n;i++) {
		   
	   
		switch(array[i][0]) {
		case 1:
			System.out.println("Product id:"+array[i][0]+", Quantity:"+array[i][1]+",Retail Value:"+array[i][0]*price[i]);
			break;
		case 2:
			System.out.println("Product id:"+array[i][0]+", Quantity:"+array[i][1]+",Retail Value:"+array[i][0]*price[i]);
			break;
		case 3:
			System.out.println("Product id:"+array[i][0]+", Quantity:"+array[i][1]+",Retail Value:"+array[i][0]*price[i]);
			break;
		case 4:
			System.out.println("Product id:"+array[i][0]+", Quantity:"+array[i][1]+",Retail Value:"+array[i][0]*price[i]);
			break;
		case 5:
			System.out.println("Product id:"+array[i][0]+", Quantity:"+array[i][1]+",Retail Value:"+array[i][0]*price[i]);
			break;
		default:
			System.out.println("No Product id");
			break;
			
		}
	
}

	
	}

}