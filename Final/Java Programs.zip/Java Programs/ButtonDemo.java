import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/* <applet code="ButtonDemo" width=400 height=300>
</applet>*/
public class ButtonDemo extends Applet implements ActionListener{
	String msg="";
	public void init(){
		Button b1=new Button("Yes");
		Button b2=new Button("No");
		Button b3=new Button("Undecided");
		add(b1);
		add(b2);
		add(b3);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae){
		String str=ae.getActionCommand();
		if(str.equals("Yes")){
			msg="You Pressed Yes..";
		}
		else if(str.equals("No")){
			msg="You Pressed No..";
		}
		else{
			msg="You Pressed undecided..";
		}
		repaint();
	}
	public void paint(Graphics g){
		g.drawString(msg,10,100);
	}
}