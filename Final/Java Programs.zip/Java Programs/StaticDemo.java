class Demo{
	static int a=10;
	static void display(){
	  System.out.println("Static method");
	}
}
class StaticDemo{
	static int a;
	public static void main(String args[]){
		System.out.println(a);
		Demo.display();
	}
}