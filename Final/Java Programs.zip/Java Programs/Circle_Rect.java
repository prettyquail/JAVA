import java.awt.*;
import java.applet.*;
/*
<applet code="Circle_Rect.class" width=300 height=200>
</applet>
*/
public class Circle_Rect extends Applet{
  public void paint(Graphics g)
  {
    g.drawRect(10,10,60,50);
    g.drawOval(20,20,30,30);
  }
}