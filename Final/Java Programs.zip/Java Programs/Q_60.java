class Q_60{
 static void two(){
	try{
	  throw new NullPointerException("Exception of one()");
	}catch(NullPointerException e){
	  System.out.println("Caught inside two method");//first two() catch the exception
	  throw e;
	}
  }
 static void one(){
	two();
  }
 public static void main(String args[]){
	
	try{
	  one();//method one should call two
	}catch(NullPointerException e){
	 System.out.println("Recaught:"+e);
	}
	}
}