import java.util.Scanner; 
public class Q_4 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int max=0;
		int min=0;
		int num;
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<5;i++) {
			num=sc.nextInt();
			if(i==0) {
				min=num;
				max=num;
			}
			if(num>max) {
				max=num;
			}
			if(num<min) {
				min=num;
			}
		}
System.out.println("Max"+max);
System.out.println("Min"+min);
	}

}