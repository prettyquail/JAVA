class Q_58{
	static void throwOne() throws IllegalAccessException{
		System.out.println("Inside throwOne");
		throw new IllegalAccessException("throwTwo");
	}
	public static void main(String args[]){
		try{
			throwOne();
		}catch(IllegalAccessException e){
			System.out.println("Caught"+ e);
		}finally{
			System.out.println("This is finally block");
		}
		System.out.println("Out of try catch block");
	}
}