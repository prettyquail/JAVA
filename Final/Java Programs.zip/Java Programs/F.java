import java.util.Scanner;
class F{

	public static void main(String args[]){
	int last,m,n,sum=0,temp,total=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the value of n");
	last=sc.nextInt();
	m=0;
	n=1;
	System.out.println("Series=");
	if (last==1){
    	System.out.println(m);
    	System.out.println(n);
    	sum=(m+n);
    }
	if (last >1){
    	for(int i=0;i<last;i++){
    		if(i>=last-2){
        	  sum=sum+m;
           }
            System.out.print(" "+m);
            total=total+m;
            temp=m+n;
        	m=n;
        	n=temp;
        }
     }
     System.out.println();
     System.out.println("No of pairs="+sum);
     System.out.println("Total sum of fibonacci numbers="+total);
    }
}