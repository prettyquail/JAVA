public class Q_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=5;
		int y=5;
		if(x<y) {
			System.out.println("X is less than Y");
		}else if(x>y){
			System.out.println("X is greater than Y");
		}else {
			System.out.println("X is equal to Y");
		}
	}

}