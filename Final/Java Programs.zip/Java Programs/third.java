import java.util.Scanner;
class third{

	public static void main(String[] arg){
 	Scanner sc=new Scanner(System.in);
	float a,b;
	System.out.println("Enter value of a and b");
	a=sc.nextFloat();
	b=sc.nextFloat();
	float mult;
	mult=a*b;
	System.out.println("Multiplication="+mult);
        }
}
