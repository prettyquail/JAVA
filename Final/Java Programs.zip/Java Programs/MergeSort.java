import java.util.Arrays;
//import java.uitl.Scanner;
class MergeSort{
  public static void merge(int [] intArray,int start, int mid, int end)
  {
    int n1 = mid-start+1;
    int n2 = end-mid;
    int L1[] = new int[n1];
    int L2[] = new int[n2];
    for(int i=0; i<n1 ; ++i)
    {   L1[i] = intArray[start+i];  }
    for(int j=0; j<n2 ; ++j)
    {   L2[j] = intArray[mid+1+j];  }
    int i=0,j=0;
    int k =start;
    while(i<n1 && j<n2)
    {
      if(L1[i]<=L2[j])  { intArray[k]=L1[i];      i++;}
      else  { intArray[k]=L2[j];      j++;}
      k++;
    }
    while(i<n1){  intArray[k] = L1[i];    i++;    k++;  }
    while(i<n1){  intArray[k] = L2[j];    j++;    k++;  }
  }
  void sort(int intArray[],int start, int end)
  {
    if(start<end)
    {
      int mid = (start + end)/2;
      sort(intArray,start,mid);
      sort(intArray,mid+1,end);
      merge(intArray,start,mid,end);
    }
  }
  static void printArray(int intArray[])
  {
    int n = intArray.length;
    for(int i=0; i<n ; ++i ) {  System.out.print(intArray[i] + " ");  }
    System.out.println();
  }

  
  public static void main(String args[])
  {
    int intArray[] = {12,11,13,5,6,7};
    System.out.println("Given Array:");
    printArray(intArray);
    MergeSort ob = new MergeSort();
    ob.sort(intArray,0,intArray.length-1);
    System.out.println("\n Sorted Array:");
    printArray(intArray);
  }
}