import java.util.Scanner;
class second {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int a,b;
		System.out.println("Enter value of a and b");
		a=sc.nextInt();
		b=sc.nextInt();
		int sum;
		sum=a+b;
		System.out.println("Addition="+sum);
	}
}
