import java.lang.String;
import java.util.Scanner;

class Stringindexof{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a String: ");
    String str = sc.nextLine();
    char c ;
    do{
    System.out.println("Enter the character: ");
    char ch;    int count=0;
    ch=sc.next().charAt(0);
    for(int i=0; i<str.length();i++)
    {
      if(str.charAt(i) == ch)
          count++;
    }
    if(count==0)
        System.out.println("No such character exist!!");
    else
        System.out.println("Number of occurrences of " + ch + " is/are: " +count);
    System.out.println("Do u want to enter more?(Y/N)");
    c=sc.next().charAt(0);
    }while(c == 'y' || c == 'Y');
  }
}