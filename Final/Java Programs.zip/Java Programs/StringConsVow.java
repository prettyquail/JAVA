
import java.lang.String;
import java.util.Scanner;

class StringConsVow{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    int cons=0 , vow = 0;
    char[] ch = {'a','e','i','o','u'};
    System.out.println("Enter a String: ");
    String str = sc.nextLine();
    str = str.toLowerCase();
    for(int i=0 ; i<str.length() ; i++)
    {
           if(str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u')
               vow++;
            else if(str.charAt(i)>= 'a' && str.charAt(i)<= 'z')
               cons++;
    }
    System.out.println("Number of consonants in the String are: " + cons + " and vowels are : " + vow);
  }
}