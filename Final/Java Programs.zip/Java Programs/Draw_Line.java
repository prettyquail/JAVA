import java.awt.*;
import java.applet.*;
/*
<applet code="Draw_Line.class" width=300 height=200>
</applet>
*/
public class Draw_Line extends Applet{
  public void paint(Graphics g)
  {
    g.drawLine(100,0,0,0);
    g.drawLine(0,100,0,0);
    g.drawLine(0,0,100,50);
  }
}