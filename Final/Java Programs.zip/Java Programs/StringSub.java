import java.lang.String;
import java.util.Scanner;

class StringSub{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    int len,start = 0,end=0;
    System.out.println("Enter a String: ");
    String str = sc.nextLine(); len=str.length();
    System.out.println("Enter a start and end of the substring: ");
    start = sc.nextInt(); end = sc.nextInt();
    if(end<=len && end!=0)
    System.out.println("Substring of the string " + str + " is\n " + str.substring(start-1,end-1));
    else {  System.out.println("End cannot be 0!!" ); }
    System.out.println("Enter to check the start of the string: ");
    String st=sc.nextLine();
    sc.nextLine();
    System.out.println(str.startsWith(st));
    System.out.println("Enter to check the end of the string: ");
    String e=sc.nextLine();
    System.out.println(str.endsWith(e));
  }
}