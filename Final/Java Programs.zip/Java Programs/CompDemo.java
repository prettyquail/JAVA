import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/* <applet code="CompDemo" width=400 height=300>
</applet>*/
public class CompDemo extends Applet{
	
	public void init(){

		Label l1=new Label("Name:");
		Button b1=new Button("Left");
		Button b2=new Button("Right");
		Button b3=new Button("Top");
		Button b4=new Button("Bottom");
		
		TextField t1=new TextField(20);
		CheckboxGroup cbg=new CheckboxGroup();
		Checkbox cb1=new Checkbox("windows",cbg,true);
		Checkbox cb2=new Checkbox("linux",cbg,false);
		Checkbox cb3=new Checkbox("Android",cbg,false);
		l1.setBounds(10,50,40,10);
		t1.setBounds(50,200,150,250);
		setLayout(new BorderLayout());

		add(b1,BorderLayout.WEST);
		add(b2,BorderLayout.EAST);
		add(b3,BorderLayout.NORTH);
		add(b4,BorderLayout.SOUTH);
   
		String msg="This is border layout";
		add(new TextArea(msg),BorderLayout.CENTER);

	}
}