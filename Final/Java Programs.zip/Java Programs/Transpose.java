import java.util.Scanner;
class Transpose{
  public static void main(String args[])
  {
    int r,c,temp;
    r = c =3;
    Scanner sc = new Scanner(System.in);
    int matrix[][] = new int[r][c];
    System.out.println("Enter the elements in the array: ");
    for(int i=0 ; i<r ; i++)
    {
      for(int j=0; j<c ; j++)
        { matrix[i][j]=sc.nextInt(); }
    }
    for(int i=0 ; i<r ; i++)
    {
      for(int j=0; j<i ; j++)
        {
           temp = matrix[i][j];
           matrix[i][j]=matrix[j][i];
           matrix[j][i]=temp;
        }
    }
    System.out.println("Transpose of the matrix is :");
    for(int i=0 ; i<r ; i++)
    {
      for(int j=0; j<c ; j++)
        { System.out.print(matrix[i][j] + "\t"); }
      System.out.print("\n");
    }
  }
}