/*error- main() method is already defined inside Doublemain
public class Doublemain {
   public static void main(String args[]){
      System.out.println("In first main");
    }
  public static void main(String args[]){
     System.out.println("Second main");
   }
}*/


public class Doublemain {
   public static void main(String args[]){
      System.out.println("In first main");}
   public static void main(char args[]){
     System.out.println("a");}
}