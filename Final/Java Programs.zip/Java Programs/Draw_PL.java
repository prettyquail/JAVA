import java.awt.*;
import java.applet.*;
/*
<applet code="Draw_PL.class" width=300 height=200>
</applet>
*/
public class Draw_PL extends Applet{
  public void paint(Graphics g)
  {
    g.drawLine(100,100,200,200);
    g.drawLine(150,150,250,250);
   /* g.drawLine(0,0,100n,50);
    g.drawLine(0,0,100n,50);*/
  }
}