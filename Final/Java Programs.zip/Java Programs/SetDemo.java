 import java.util.*;

class SetDemo
{
public static void main(String as[])
{
HashSet set =new HashSet();
set.add(12345);
set.add('C');
set.add("C++");
set.add(true);
set.add("C++");
set.add(49.29);
System.out.println("Set is : "+set);
//System.out.println("size of Set is : "+set.size());
//set.remove(49.29);
//System.out.println("Now,the Set is : "+set);
//set.clear();
//System.out.println("is Set is blank? "+set.isEmpty());
HashSet set2=new HashSet();
set2.add("one");
set2.add("two");
set2.add("three");
set2.add('C');
set2.add("four");
set2.add("five");
set.add(set2);
//set.addAll(set2);
System.out.println("Now,the Set is : "+set);
System.out.println("size of Set is : "+set.size());
set.removeAll(set2);
set.retainAll(set2);
//System.out.println("Now,the Set is : "+set);
/*
Object obj[]=set.toArray();
for(int i=0;i<set.size();i++)
	System.out.println("The member is : "+obj[i]);*/

/*Iterator it=set.iterator();
while(it.hasNext())
	System.out.println(it.next());
*/

}
}
